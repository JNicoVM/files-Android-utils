package co.com.sportiapp.view.chat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Adapter
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import co.com.sportiapp.R
import co.com.sportiapp.dataBase.appDatabase.AppDataBase
import co.com.sportiapp.databinding.ActivityChatProfileBinding
import co.com.sportiapp.databinding.ActivityEditProfileBinding
import co.com.sportiapp.model.ChatModel
import co.com.sportiapp.model.User
import co.com.sportiapp.view.base.BaseActivity
import co.com.sportiapp.view.chat.adapters.ItemsChatUserAdapter
import co.com.sportiapp.view.chat.viewModel.ChatProfileViewModel
import co.com.sportiapp.view.dialogs.DialogModel
import co.com.sportiapp.view.dialogs.showInfoDialog
import co.com.sportiapp.view.login.Login
import co.com.sportiapp.view.registro.viewmodel.EditProfileViewModel
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore


class ChatProfile : BaseActivity(), ChatProfileViewModel.Listener {

    companion object{
        fun startActivity(context: Context){
            val intent = Intent(context, ChatProfile::class.java)
            context.startActivity(intent)
        }
    }

    lateinit var binding: ActivityChatProfileBinding
    val firebaseFirestore = FirebaseFirestore.getInstance()

    private val viewModel : ChatProfileViewModel by lazy{
        ViewModelProvider(this).get(ChatProfileViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_chat_profile)
        binding.viewmodel = viewModel
        viewModel.listener = this
        viewModel.getChats(firebaseAuth?.uid?:"")
        binding.rvComents.layoutManager = LinearLayoutManager(this)
        val variosChats: ArrayList<ChatModel> = arrayListOf()
        viewModel.listChats.observe(this, Observer { listaChats->
            viewModel.getChatsSegunsaLista(firebaseAuth?.uid?:"")
            viewModel.listChats2.observe(this, Observer { listaChats2->
                val listaChatsTotal = listaChats + listaChats2
                listaChatsTotal.distinct().forEach { chatModelo->
                    if(chatModelo.usuario1.split("/")[1]==firebaseAuth?.uid?:""){
                        firebaseFirestore.collection(
                            "usuarios"
                        ).document(chatModelo.usuario2.split("/")[1])
                            .get()
                            .addOnSuccessListener {
                                chatModelo.user = it.toObject(User::class.java) as User
                                variosChats.add(chatModelo)
                                binding.rvComents.adapter = ItemsChatUserAdapter(this, variosChats)
                            }
                    }else if(chatModelo.usuario2.split("/")[1]==firebaseAuth?.uid?:""){
                        firebaseFirestore.collection(
                            "usuarios"
                        ).document(chatModelo.usuario1.split("/")[1])
                            .get()
                            .addOnSuccessListener {
                                chatModelo.user = it.toObject(User::class.java) as User
                                variosChats.add(chatModelo)
                                binding.rvComents.adapter = ItemsChatUserAdapter(this, variosChats)
                            }
                    }
                }
            })

        })

        binding.volver.setOnClickListener {
            finish()
        }
    }

    override fun cancel() {
        onBackPressed()
    }

    override fun error(message: String) {
        showInfoDialog(
            DialogModel(
                mensaje = message
            )
        )
    }


}