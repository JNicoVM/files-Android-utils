package com.wigilabs.progressus.app.network

import com.google.gson.JsonObject
import com.wigilabs.progressus.modelos.*
import io.reactivex.Observable
import org.json.JSONObject
import retrofit2.http.*

interface ProgressusNetwork {
    companion object {
        const val TOKEN_AUTHOTIZATION = "Authorization"
    }

    /** API INICIO DE SESIÓN*/
    @POST("obtOrganizaciones")
    fun inicioSesion(@Body modeloInicioSesion: ModeloInicioSesion): Observable<JsonObject>


    /** API REGISTRO AGRICULTOR*/
    @POST("regAgricultor")
    fun registroAgricultor(@Body modeloRegistroAgricultor: ModeloRegistroAgricultor):Observable<JsonObject>

    /** API REGISTRO AGRONOMO*/
    @POST("regAgronomo")
    fun registroAgronomo(@Body modeloRegistroAagronomo: ModeloRegistroAgronomo):Observable<JsonObject>

    /** API REGISTRO USUARIO*/
    @POST("regAgricultor")
    fun registroUsuario(@Body modeloRegistroUsuario: ModeloRegistroUsuario):Observable<JsonObject>

    /** API ENVIAR SMS*/
    @POST("sendCodeNumber")
    fun enviarSMS(@Body modeloEnvioSMS: ModeloEnvioSMS):Observable<JsonObject>

    /** API ENVIAR SMS*/
    @POST("sendCodeNumber")
    fun enviarPRUEBA(@Body jsonSMS: JsonObject):Observable<JsonObject>

    /** API VERIFICAR CODE*/
    @POST("validateCode")
    fun verificarCodigo(@Body modeloEnvioValidarSMS: ModeloEnvioValidarSMS):Observable<JsonObject>

    /** API CAMBIAR CONTRASENA*/
    @POST("cambiarContrasena")
    fun cambiarContrasena(@Body modeloEnvioCambioContra: ModeloEnvioCambioContra):Observable<JsonObject>

    /** API CAMBIAR CONTRASENA*/
    @GET("getOrganizacionesRegistro")
    fun obtenerOrganizaciones():Observable<JsonObject>
}