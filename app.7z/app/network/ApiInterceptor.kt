package com.wigilabs.progressus.app.network

import android.content.Context
import android.os.Build
import com.google.gson.JsonParser
import com.wigilabs.progressus.BuildConfig
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okhttp3.Response
import okhttp3.ResponseBody
import okio.Buffer
import org.json.JSONObject

class ApiInterceptor(val context: Context):Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        if (chain == null) throw Throwable("chain is null")
        //val tkpS = context.loadEncryptedData("tkpS")
        val response = when (chain.request().method) {
            "POST", "PUT" -> {
                val buffer = Buffer()
                chain.request().body?.writeTo(buffer)
                val bufferUtf8 = buffer.readUtf8()
                val mediaType = "application/json; charset=UTF-8".toMediaTypeOrNull()
                val jsonObject = JsonParser().parse(bufferUtf8)
                // jsonObject.add("data", JsonParser().parse(bufferUtf8))
                val requestBody = RequestBody.create(mediaType, jsonObject.toString())
                val headers = chain.request().newBuilder()
                    .headers(chain.request().headers)
                    .header("Content-Type", requestBody.contentType().toString())
                    .header("Content-Length", requestBody.contentLength().toString())
                    .header("X-MC-SO", "android")
                    .header("Cache-Control", "no-cache")
                    .header("X-MC-SO-V", Build.VERSION.RELEASE)
                    .header("X-MC-SO-API", Build.VERSION.SDK_INT.toString())
                    .header("X-MC-SO-PHONE-F", Build.MANUFACTURER)
                    .header("X-MC-SO-PHONE-M", Build.MODEL)
                val request = headers
                    .method(chain.request().method, requestBody).build()

                chain.proceed(request)
            }
            else -> {
                val headers = chain.request().newBuilder()
                    .headers(chain.request().headers)
                    .header("X-MC-SO", "android")
                    .header("X-MC-SO-V", Build.VERSION.RELEASE)
                    .header("Cache-Control", "no-cache")
                    .header("X-MC-SO-API", Build.VERSION.SDK_INT.toString())
                    .header("X-MC-SO-PHONE-F", Build.MANUFACTURER)
                    .header("X-MC-SO-PHONE-M", Build.MODEL)
                    .header("X-MC-APP-V", BuildConfig.VERSION_NAME)
                chain.proceed(headers.build())
            }
        }
        var jsonResponse = response.body?.string() ?: ""
        if (jsonResponse.contains("[")) {
            val jo = JSONObject()
            //Populate the array
            val parser = JsonParser()
            val elem = parser.parse(jsonResponse)
            val elemArr = elem.asJsonArray
            jo.put("data", elemArr)
            jsonResponse = jo.toString()
        }
        return response.newBuilder()
            .body(ResponseBody.create(response.body?.contentType(), jsonResponse)).build()
    }
}