package com.wigilabs.progressus.app



import android.content.Context
import android.util.Log
import androidx.core.content.contentValuesOf
import com.google.gson.JsonObject
import com.wigilabs.progressus.BuildConfig
import com.wigilabs.progressus.R
import com.wigilabs.progressus.app.network.ProgressusNetwork
import com.wigilabs.progressus.modelos.*
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class ProgressusCliente(val context: Context) {

    private val interceptor=HttpLoggingInterceptor()
        .setLevel(HttpLoggingInterceptor.Level.BODY)

    private val cliente=OkHttpClient.Builder()
        .addInterceptor(interceptor)
        .connectTimeout(40,TimeUnit.SECONDS)
        .build()

    private val interfazApi:ProgressusNetwork= Retrofit.Builder()
        .client(cliente)
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .addConverterFactory(GsonConverterFactory.create())
        .baseUrl(BuildConfig.BASE_URL)
        .build()
        .create(ProgressusNetwork::class.java)


    private fun configuracionRx(jsonObjectObservable: Observable<JsonObject>):Observable<JsonObject>
            =jsonObjectObservable.subscribeOn(Schedulers.newThread())
        .observeOn(AndroidSchedulers.mainThread())
        .onErrorReturn(this::obtenerError)


    private fun obtenerError(throwable: Throwable): JsonObject {
        val error="${throwable.message} Class: ${throwable.javaClass.name}"
        Log.e("Api Error",error,throwable)
        val jsonObject=JsonObject()
        val mensajeError= when(throwable) {
            is SocketTimeoutException ->
                this.context.getString(R.string.NoTienesConexionAInternet)
            is UnknownHostException ->
                this.context.getString(R.string.NoTienesConexionAInternet)
            else ->
                this.context.getString(R.string.HaOcurridoUnErrorIntentaloMasTarde)
        }
        jsonObject.addProperty("response",mensajeError)
        return jsonObject
    }

    /** Api Login*/
    fun iniciarSesion(modeloInicioSesion: ModeloInicioSesion): Observable<JsonObject> =
        configuracionRx(interfazApi.inicioSesion(modeloInicioSesion))

    /** Api Registro*/
    fun registroAgricultor(modeloAgricultor: ModeloRegistroAgricultor):Observable<JsonObject> =
        configuracionRx(interfazApi.registroAgricultor(modeloAgricultor))
    fun registroAgronomo(modeloAgronomo: ModeloRegistroAgronomo):Observable<JsonObject> =
        configuracionRx(interfazApi.registroAgronomo(modeloAgronomo))
    fun registroUsuario(modeloUsuario: ModeloRegistroUsuario):Observable<JsonObject> =
        configuracionRx(interfazApi.registroUsuario(modeloUsuario))
    fun obtenerOrganizaciones():Observable<JsonObject> =
        configuracionRx(interfazApi.obtenerOrganizaciones())

    /** Api RecuperarContrasena*/
    fun enviarSMS(modeloEnvioSMS: ModeloEnvioSMS):Observable<JsonObject> =
        configuracionRx(interfazApi.enviarSMS(modeloEnvioSMS))
    fun verificarCodeSMS(modeloEnvioValidarSMS: ModeloEnvioValidarSMS):Observable<JsonObject> =
        configuracionRx(interfazApi.verificarCodigo(modeloEnvioValidarSMS))
    fun cambiarContrasena(modeloEnvioCambioContra: ModeloEnvioCambioContra):Observable<JsonObject> =
        configuracionRx(interfazApi.cambiarContrasena(modeloEnvioCambioContra))

}