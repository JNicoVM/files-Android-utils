package com.clarocolombia.miclaro.dialogs

import android.app.Dialog
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentManager
import com.clarocolombia.miclaro.`typealias`.CallbackEmpty
import com.clarocolombia.miclaro.base.BaseDialogFragment
import com.clarocolombia.miclaro.databinding.DialogUltraWifiConfirmationBinding

class DialogUltraWifiConfirmation : BaseDialogFragment() {

    lateinit var binding: DialogUltraWifiConfirmationBinding
    private var onClickAccept: CallbackEmpty? = null
    private var onClickCancel: CallbackEmpty? = null
    private var title: String? = null
    private var titleAccept: String? = null
    private var titleCancel: String? = null

    @DrawableRes
    private var icon: Int? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val activity = this.activity ?: return super.onCreateDialog(savedInstanceState)
        val builder = AlertDialog.Builder(activity)

        binding = DialogUltraWifiConfirmationBinding.inflate(activity.layoutInflater)
        builder.setView(binding.root)
        initView()
        initListener()
        return builder.create()
    }

    private fun initListener() {
        binding.btnCancel.setOnClickListener {
            onClickCancel?.invoke()
            dismiss()
        }

        binding.btnAccept.setOnClickListener {
            onClickAccept?.invoke()
            dismiss()
        }

        binding.btnAcceptOnly.setOnClickListener {
            onClickAccept?.invoke()
            dismiss()
        }
    }

    private fun initView() {
        setText(binding.tvTitle)

        icon?.let {
            binding.imgIcon.setImageResource(it)
        }

        if (titleCancel.isNullOrEmpty())
            binding.btnAcceptOnly.visibility = View.VISIBLE
        else
            binding.cntButtons.visibility = View.VISIBLE
    }

    private fun setText(textView: TextView) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            textView.text = Html.fromHtml(title, Html.FROM_HTML_MODE_COMPACT)
        } else {
            @Suppress("DEPRECATION")
            textView.text = Html.fromHtml(title)
        }
    }

    fun showDialog(
        fragmentManager: FragmentManager,
        title: String? = null,
        titleAccept: String? = null,
        titleCancel: String? = null,
        icon: Int? = null,
        accept: CallbackEmpty? = null,
        cancel: CallbackEmpty? = null
    ) {
        this.onClickAccept = accept
        this.onClickCancel = cancel
        this.title = title
        this.icon = icon
        this.titleAccept = titleAccept
        this.titleCancel = titleCancel
        this.show(fragmentManager, DialogUltraWifiConfirmation::class.java.name)
    }

}
