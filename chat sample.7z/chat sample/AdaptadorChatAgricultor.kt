package com.wigilabs.progressus.adaptadores

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Timestamp
import com.squareup.picasso.Picasso
import com.wigilabs.progressus.R
import com.wigilabs.progressus.databinding.ItemMensajeChatEnviadoBinding
import com.wigilabs.progressus.databinding.ItemMensajeChatRecibidoBinding
import com.wigilabs.progressus.modelos.ModeloMensaje
import com.wigilabs.progressus.utils.toReadableFormat
import java.util.*
import kotlin.collections.ArrayList

class AdaptadorChatAgricultor: RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val viewTypeRecibido = 2
    private val viewTypeEnviado = 1
    private var mensajes: ArrayList<ModeloMensaje> = ArrayList()

    class HolderMensajeEnviadoAdapter(view: View) : RecyclerView.ViewHolder(view) {
        val binding: ItemMensajeChatEnviadoBinding = ItemMensajeChatEnviadoBinding.bind(view)
    }

    class HolderMensajeRecibidoAdapter(view: View) : RecyclerView.ViewHolder(view) {
        val binding: ItemMensajeChatRecibidoBinding = ItemMensajeChatRecibidoBinding.bind(view)
    }


    override fun onCreateViewHolder(p0: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var view = LayoutInflater.from(p0.context)
            .inflate(R.layout.item_mensaje_chat_enviado,
                p0, false)
        return if(viewType == viewTypeRecibido) {
            view = LayoutInflater.from(p0.context).inflate(R.layout.item_mensaje_chat_recibido,
                p0, false)
            HolderMensajeRecibidoAdapter(view)
        }else{
            HolderMensajeEnviadoAdapter(view)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if(mensajes[position].from==2){
            viewTypeEnviado
        }else{
            viewTypeRecibido
        }
    }

    override fun getItemCount(): Int = mensajes.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewType = getItemViewType(position)
        val mensaje = mensajes[position]
        if(viewType == viewTypeEnviado) {
            val holderMensajeEnviadoAdapter: HolderMensajeEnviadoAdapter = holder as HolderMensajeEnviadoAdapter
            if(mensaje.foto.isNotEmpty()){
                holderMensajeEnviadoAdapter.binding.img.visibility = View.VISIBLE
                Picasso.get()
                    .load(mensaje.foto)
                    .resize(200,200)
                    .centerCrop()
                    .into(holderMensajeEnviadoAdapter.binding.img)
            }else{
                holderMensajeEnviadoAdapter.binding.img.visibility = View.GONE
            }
            if(mensaje.fecha==null) {
                mensaje.fecha = Timestamp(Date())
            }
            holderMensajeEnviadoAdapter.binding.tvFecha.text = mensaje.fecha!!.toDate().toReadableFormat("dd/MM/yyyy")
            holderMensajeEnviadoAdapter.binding.tvMensaje.text = mensaje.mensaje
            holderMensajeEnviadoAdapter.binding.tvHora.text = mensaje.fecha!!.toDate().toReadableFormat("HH:mm")
        }else{
            val holderMensajeRecibidoAdapter: HolderMensajeRecibidoAdapter = holder as HolderMensajeRecibidoAdapter
            holderMensajeRecibidoAdapter.binding.tvFecha.text = mensaje.fecha!!.toDate().toReadableFormat("dd/MM/yyyy")
            holderMensajeRecibidoAdapter.binding.tvMensaje.text = mensaje.mensaje
            holderMensajeRecibidoAdapter.binding.tvHora.text = mensaje.fecha!!.toDate().toReadableFormat("HH:mm")
            if(mensaje.foto.isNotEmpty()){
                holderMensajeRecibidoAdapter.binding.tvMensaje.visibility = View.GONE
                holderMensajeRecibidoAdapter.binding.img.visibility = View.VISIBLE
                Picasso.get()
                    .load(mensaje.foto)
                    .resize(400,400)
                    .centerCrop()
                    .into(holderMensajeRecibidoAdapter.binding.img)
            }else{
                holderMensajeRecibidoAdapter.binding.tvMensaje.visibility = View.VISIBLE
                holderMensajeRecibidoAdapter.binding.img.visibility = View.GONE
            }
        }
    }


    fun agregarMensajes(mensajes: ArrayList<ModeloMensaje>){
        this.mensajes = mensajes
        notifyDataSetChanged()
    }

}