package com.wigilabs.progressus.agricultor.agendaChatAgricultor.fragments

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.wigilabs.progressus.R
import com.wigilabs.progressus.adaptadores.AdaptadorChatAgricultor
import com.wigilabs.progressus.agricultor.agendaChatAgricultor.viewModel.ViewModelAgendaChatAgricultor
import com.wigilabs.progressus.base.FragmentBase
import com.wigilabs.progressus.databinding.FragmentChatAgricultorBinding
import com.wigilabs.progressus.dialogos.AgregarFotoDialog
import com.wigilabs.progressus.dialogos.DialogoDeAlerta
import com.wigilabs.progressus.modelos.ModeloMensaje
import com.wigilabs.progressus.utils.*
import load
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


/**
 * A simple [Fragment] subclass.
 */

class FragmentChatAgricultor
    : FragmentBase(), ViewModelAgendaChatAgricultor.Listener {

    companion object {
        //image pick code
        private const val IMAGE_PICK_CODE = 1000
        private const val REQUEST_IMAGE_CAPTURE = 1

        //Permission code
        const val PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 10127
        const val PERMISSIONS_REQUEST_CAMERA = 10128
    }

    private lateinit var binding: FragmentChatAgricultorBinding
    private lateinit var viewModel: ViewModelAgendaChatAgricultor
    private lateinit var adaptadorChatAgricultor: AdaptadorChatAgricultor
    private var database: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val agregarFotoDialog = AgregarFotoDialog()
    private var imagenUri: Uri? = null
    private lateinit var fileCache: File
    private var idAgronomo = ""
    private var idAgricultor = ""
    private var agriPadre = ""
    private var listaDeListener: ArrayList<ListenerRegistration?> = arrayListOf()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_chat_agricultor,
            container, false
        )
        initViews()
        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        obtenerMensajes()

        return binding.root
    }


    private fun initViews() {
        adaptadorChatAgricultor = AdaptadorChatAgricultor()
        binding.rvChat.layoutManager = LinearLayoutManager(this.context)
        binding.rvChat.adapter = adaptadorChatAgricultor
        binding.btnAgregarFoto.setOnClickListener {
            showDialogAgregarFoto()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        idAgronomo = activity?.load("idAgronomo")?:""
        idAgricultor = activity?.load("idAgricultor")?:""
        agriPadre = activity?.load("agriPadre") ?: ""
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(ViewModelAgendaChatAgricultor::class.java)
        viewModel.listener = this
        binding.viewModel = viewModel
        tituloBarraDeAccionVerde(R.string.Agendas, activity)
    }


    private fun showDialogAgregarFoto() {
        if (isInternetAvailable(activity!!)) {
            agregarFotoDialog.onClickTomarFoto = {
                if (checkPermission(activity!!, true)) {
                    openCamara()
                }
            }
            agregarFotoDialog.onClickAbrirGaleria = {
                if (checkPermission(activity!!, false)) {
                    pickImageFromGallery()
                }
            }
            agregarFotoDialog.show(activity as AppCompatActivity)
        } else {
            val dialogoDeAlerta = DialogoDeAlerta(
                true,
                getString(R.string.SinConexionAInternet),
                getString(R.string.sin_internet_no_es_posible),
                null,
                getString(R.string.Aceptar),
                dialogoAzul = false,
                showEditText = false
            )
            dialogoDeAlerta.show(
                activity!!.supportFragmentManager,
                DialogoDeAlerta::class.java.name
            )
            dialogoDeAlerta.onClickAceptar = {
                dialogoDeAlerta.dismiss()
            }
        }

    }


    override fun subirImagen() {
        val storage: StorageReference = FirebaseStorage.getInstance().reference
        val filePath: StorageReference = storage
            .child("fotosChat")
            .child(imagenUri?.lastPathSegment ?: "none")
        imagenUri?.let { uriLocal ->
            filePath.putFile(uriLocal).addOnCompleteListener {
                if (it.isSuccessful) {
                    it.result?.metadata?.reference?.downloadUrl?.addOnCompleteListener { result ->
                        if (result.isSuccessful) {
                            val urlImagen = result.result.toString()
                            enviarMensajeConFoto(urlImagen)
                            if (fileCache.exists())
                                fileCache.delete()
                        } else {
                            Toast.makeText(
                                activity,
                                "No se pudo enviar la imagen",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } else {
                    Toast.makeText(activity, "No se pudo enviar la imagen", Toast.LENGTH_LONG)
                        .show()
                }
            }
        }
    }

    override fun mostrarDialogoDatePicker(view: View) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun enviar(mensaje: String) {
        if (agriPadre == "") {
            val messageRef = database.collection("chats").document(idAgronomo)
                .collection("agricultores").document(idAgricultor)
                .collection("mensajes")
            //ServerValue.TIMESTAMP
            val msm = hashMapOf(
                "fecha" to FieldValue.serverTimestamp(),
                "foto" to "",
                "from" to 2,
                "leido" to false,
                "mensaje" to mensaje
            )

            messageRef.add(msm)
            binding.etEscribe.text?.clear()
        } else {
            val messageRef = database.collection("chats").document(idAgronomo)
                .collection("agricultores").document(agriPadre)
                .collection("mensajes")
            //ServerValue.TIMESTAMP
            val msm = hashMapOf(
                "fecha" to FieldValue.serverTimestamp(),
                "foto" to "",
                "from" to 2,
                "leido" to false,
                "mensaje" to mensaje
            )
            messageRef.add(msm)
            binding.etEscribe.text?.clear()
        }

    }

    private fun obtenerMensajes() {

        when (agriPadre) {
            "" -> {
                val messageRef = database.collection("chats").document(idAgronomo)
                    .collection("agricultores").document(idAgricultor)
                    .collection("mensajes").orderBy(
                        "fecha",
                        Query.Direction.ASCENDING
                    )
                val escuchadorMensajes = messageRef.addSnapshotListener { snapshot, e ->
                    binding.contentLoadingProgressBar.visibility = View.GONE
                    if (e != null) {
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val mensajes = snapshot.toObjects(ModeloMensaje::class.java)
                            .toMutableList() as ArrayList<ModeloMensaje>
                        adaptadorChatAgricultor.agregarMensajes(mensajes)
                        binding.rvChat.scrollToPosition(mensajes.size - 1)
                    }
                }
                listaDeListener.add(escuchadorMensajes)
            }
            else -> {
                val messageRef = database.collection("chats").document(idAgronomo)
                    .collection("agricultores").document(agriPadre)
                    .collection("mensajes").orderBy(
                        "fecha",
                        Query.Direction.ASCENDING
                    )
                val escuchadorMensajes = messageRef.addSnapshotListener { snapshot, e ->
                    binding.contentLoadingProgressBar.visibility = View.GONE
                    if (e != null) {
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val mensajes = snapshot.toObjects(ModeloMensaje::class.java)
                            .toMutableList() as ArrayList<ModeloMensaje>
                        adaptadorChatAgricultor.agregarMensajes(mensajes)
                        binding.rvChat.scrollToPosition(mensajes.size - 1)
                    }
                }
                listaDeListener.add(escuchadorMensajes)
            }
        }

    }


    private fun enviarMensajeConFoto(urlImagen: String) {
        if (agriPadre == "") {
            val messageRef = database.collection("chats").document(idAgronomo)
                .collection("agricultores").document(idAgricultor)
                .collection("mensajes")
            //ServerValue.TIMESTAMP
            val msm = hashMapOf(
                "fecha" to FieldValue.serverTimestamp(),
                "foto" to urlImagen,
                "from" to 2,
                "leido" to false,
                "mensaje" to ""
            )
            messageRef.add(msm)
        } else {
            val messageRef = database.collection("chats").document(idAgronomo)
                .collection("agricultores").document(agriPadre)
                .collection("mensajes")
            //ServerValue.TIMESTAMP
            val msm = hashMapOf(
                "fecha" to FieldValue.serverTimestamp(),
                "foto" to urlImagen,
                "from" to 2,
                "leido" to false,
                "mensaje" to ""
            )
            messageRef.add(msm)
        }

    }

    private fun openCamara() {
        /*
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(activity!!.packageManager)?.also {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            }
        }
        */
        val nombreImagen = "IMG-" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

        val outputImage = File(activity!!.externalCacheDir, "$nombreImagen.jpg")

        if (outputImage.exists()) {
            outputImage.delete()
        }
        outputImage.createNewFile()
        imagenUri = if (Build.VERSION.SDK_INT >= 24) {
            FileProvider.getUriForFile(activity!!, "com.wigilabs.progressus", outputImage)
        } else {
            Uri.fromFile(outputImage)
        }
        //val imageCaptureDestination = outputImage.absolutePath
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imagenUri)
        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
    }

    private fun pickImageFromGallery() {
        //Intent to pick image
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_PICK_CODE)
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE
            || requestCode == PERMISSIONS_REQUEST_CAMERA
        ) {
            if (grantResults.isNotEmpty()
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(
                    activity!!, getString(R.string.permiso_concedido),
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    activity!!, getString(R.string.permiso_denegado),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == IMAGE_PICK_CODE) {
                fileCache = crearCopia(data?.data, activity!!)
                imagenUri = Uri.fromFile(fileCache)
                subirImagen()
            } else if (requestCode == REQUEST_IMAGE_CAPTURE) {
                imagenUri?.let {
                    fileCache = procesarImagen(
                        File(
                            activity!!.externalCacheDir,
                            it.lastPathSegment ?: "none"
                        )
                    )
                    subirImagen()
                }
            }
            Toast.makeText(activity!!, "Enviando foto...", Toast.LENGTH_LONG).show()
            agregarFotoDialog.dismiss()
        }
    }

    override fun onStop() {
        super.onStop()
        listaDeListener.forEach {
            it?.remove()
        }
        listaDeListener.clear()
    }


}
